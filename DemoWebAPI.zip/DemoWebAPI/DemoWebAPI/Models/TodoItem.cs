﻿using System;

namespace DemoWebAPI.Models
{
    public class TodoItem
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public bool Iscomplete { get; set; }
    }

}
